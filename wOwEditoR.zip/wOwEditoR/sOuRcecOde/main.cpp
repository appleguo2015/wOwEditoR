#include <iostream>
#include <fstream>
#include <vector>
#include <string>

using namespace std;

int main() {
    vector<string> lines;
    string filename;
    string input;
    cout << "WELOME TO USE WOW EDITOR\n";
    cout << "1. NEW FILE\n";
    cout << "2. OPEN FILE\n";
    cout << "3. SAVE\n";
    cout << "4. QUIT\n";

    while (true) {
        cout << "\nOPERATE(1-4): ";
        int choice;
        cin >> choice;
        cin.ignore(); // 清除缓冲区!!!
/*
 ____                _____       _                _    _       
|  _ \              |  __ \     | |              | |  | |      
| |_) |_   _    __ _| |__) | __ | |     ___  __ _| |  | | ___  
|  _ <| | | |  / _` |  ___/ '_ \| |    / _ \/ _` | |  | |/ _ \ 
| |_) | |_| | | (_| | |   | |_) | |___|  __/ (_| | |__| | (_) |
|____/ \__, |  \__,_|_|   | .__/|______\___|\__, |\____/ \___/ 
        __/ |             | |                __/ |             
       |___/              |_|               |___/              

*/
        switch (choice) {
            case 1: { // 新建!!!
                lines.clear();
                cout << "TEXT(ENTER TO DONE):\n";
                while (getline(cin, input) && !input.empty()) {
                    lines.push_back(input);
                }
                filename = "";
                break;
            }
            
            case 2: { // 打开!!!
                cout << "PLZ INPUT FILENAME: ";
                getline(cin, filename);
                ifstream file(filename);
                if (!file) {
                    cout << "FAIL OPEN!!!\n";
                    break;
                }
                lines.clear();
                while (getline(file, input)) {
                    lines.push_back(input);
                }
                file.close();
                cout << "LOADING...\n";
                break;
            }
            
            case 3: { // 保存!!!
                if (filename.empty()) {
                    cout << "PLZ INPUT FILENAME: ";
                    getline(cin, filename);
                }
                ofstream outFile(filename);
                if (!outFile) {
                    cout << "FAIL SAVE\n";
                    break;
                }
                for (const auto& line : lines) {
                    outFile << line << "\n";
                }
                outFile.close();
                cout << "SAVED!!!\n";
                break;
            }
            
            case 4: // 退出!
                cout << "By aPpLegUo\n";
                return 0;
            
            default:
                cout << "FAIL OPERATE!!!\n";
        }

        // 显示当前内容~
        cout << "\nTEXT:\n";
        for (const auto& line : lines) {
            cout << line << "\n";
        }
    }
}